---
applyTo: "**/*.cs,**/*.cshtml,**/*.config,**/*.json,**/*.js,**/*.ts,**/*.tsx,**/*.sql"
---

# .NET Parity Migration Instructions

When editing files covered by this rule, treat the task as a parity migration unless the user explicitly says otherwise.

## Required behavior

- Preserve legacy contract and behavior.
- Do not add features or refactor business logic.
- Do not modernize API contracts during Phase 1.
- Do not change JSON shape or view output without a documented baseline difference and explicit approval.

## Risk areas

Pay special attention to:

- `Request.Params` vs Form/Query/Cookie fallback.
- MVC5 `Json(string)` vs ASP.NET Core `Content`/`Ok`/`Json` behavior.
- FormsAuthentication to CookieAuthentication.
- InProc Session to ASP.NET Core Session/Distributed Session.
- `HttpContext.Current` and `Server.MapPath`.
- `JavaScriptSerializer` vs `System.Text.Json`/Newtonsoft.
- DateTime, enum, null handling, PascalCase/camelCase.
- Razor helper differences.
- BundleConfig/static file paths.
- Deep link / encryption compatibility.

## Done means

Build passes AND contract regression against Golden Master passes.
