# GitHub Copilot Instructions — .NET Parity Migration

This project follows **1:1 parity migration** from .NET legacy to .NET 8+.

- Preserve external API and UI behavior exactly.
- Do not invent features, validation, permissions, DTO fields, endpoints, views, or business rules.
- Do not change request/response names, casing, data types, null behavior, DateTime format, enum format, HTTP status, redirects, cookies, sessions, content-type, static asset paths, or view HTML unless explicitly approved.
- Before modifying an endpoint/view, look for or create a Golden Master baseline.
- Compare migrated output with legacy baseline before marking work complete.
- Keep parity migration separate from modernization/refactor.
- Prefer compatibility adapters for `System.Web`, `Request.Params`, FormsAuthentication, Session, JsonResult, Server.MapPath, and legacy file/static behavior.
- Never expose or commit secrets from Web.config/appsettings/environment.

When producing code, include the minimal necessary changes and mention any compatibility risk.
