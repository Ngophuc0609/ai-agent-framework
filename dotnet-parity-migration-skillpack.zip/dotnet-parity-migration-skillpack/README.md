# .NET Legacy → .NET 8+ Parity Migration Skill Pack

Bộ skill/rules này dùng cho AI coding agents khi migrate hệ thống .NET legacy sang .NET 8 hoặc mới hơn theo chuẩn **1:1 Logic & Contract Parity**.

Mục tiêu: nâng cấp nền tảng bên trong nhưng giữ nguyên mọi hành vi bên ngoài:

- Không đổi endpoint, HTTP method, route, query/form/body/header/cookie.
- Không đổi kiểu dữ liệu, casing, null behavior, DateTime format, enum format.
- Không đổi cấu trúc object JSON/XML/HTML.
- Không đổi HTTP status, redirect, content-type, response header.
- Không đổi view, layout, script order, static asset path nếu frontend đang phụ thuộc.
- Không thêm validation, permission, business rule hoặc tính năng mới.
- Không refactor nghiệp vụ trong phase parity migration.

## Cấu trúc gói

```text
.
├── AGENTS.md                                      # Dùng chung cho Codex, VS Code, Cursor, agent đọc AGENTS.md
├── CLAUDE.md                                      # Dùng cho Claude Code
├── .github/copilot-instructions.md               # GitHub Copilot repository instruction
├── .github/instructions/dotnet-parity-migration.instructions.md
├── .clinerules/dotnet-parity-migration.md         # Cline workspace rule
├── .cursor/rules/dotnet-parity-migration.mdc      # Cursor project rule
├── .agents/skills/                                # Antigravity skills
│   ├── dotnet-parity-migration/SKILL.md
│   ├── dotnet-baseline-capture/SKILL.md
│   ├── dotnet-contract-regression/SKILL.md
│   └── dotnet-compatibility-port/SKILL.md
├── prompts/
│   ├── 00_master_migration_prompt.md
│   ├── 01_legacy_baseline_prompt.md
│   ├── 02_porting_prompt.md
│   └── 03_regression_review_prompt.md
└── templates/
    ├── endpoint-contract.template.md
    ├── golden-master-test-case.template.md
    ├── migration-acceptance-checklist.md
    ├── migration-risk-register.template.md
    └── legacy-baseline.schema.json
```

## Cách dùng nhanh

1. Copy toàn bộ nội dung gói này vào root repo legacy hoặc repo migration.
2. Trước khi yêu cầu AI convert code, luôn chạy prompt: `prompts/01_legacy_baseline_prompt.md`.
3. Chỉ cho AI port code khi đã có baseline tối thiểu cho endpoint/view cần migrate.
4. Sau khi port từng endpoint/view, chạy prompt: `prompts/03_regression_review_prompt.md` để so với Golden Master.
5. Nếu có khác biệt contract mà không được phê duyệt, coi là lỗi migration.

## Phase bắt buộc

```text
Phase 0 - Legacy Inventory
Phase 1 - Golden Master Baseline
Phase 2 - Compatibility Design
Phase 3 - Minimal Porting
Phase 4 - Contract Regression
Phase 5 - Browser/View Regression
Phase 6 - Staging/Cutover/Rollback
```

## Nguyên tắc khóa

**Build pass không có nghĩa migrate đúng.** Một endpoint/view chỉ được đánh dấu Done khi input/output/status/header/cookie/session/view/side-effect khớp baseline legacy.
