# CLAUDE.md — .NET Legacy → .NET 8+ Parity Migration

This repository uses a strict **1:1 Logic & Contract Parity** migration policy.

When working on migration tasks, follow `AGENTS.md` first. If there is a conflict, the stricter compatibility rule wins.

## Always remember

- This migration must not change external behavior.
- Treat legacy behavior as the source of truth, even if the old code looks ugly.
- A build without errors is not acceptance.
- A migration is complete only when the Golden Master comparison passes.
- Any output difference must be classified as either:
  - approved breaking change, or
  - migration bug.

## Before editing code

Create or inspect these artifacts:

- Endpoint inventory.
- View inventory.
- Config inventory.
- Auth/session/cookie map.
- JSON compatibility profile.
- Crypto/deep-link test vector.
- External integration map.
- Database/side-effect matrix.
- Golden Master snapshots.

## Use this response pattern

```text
I found:
- ...

I will preserve:
- ...

Risk:
- ...

I changed:
- ...

Verification:
- ...
```
