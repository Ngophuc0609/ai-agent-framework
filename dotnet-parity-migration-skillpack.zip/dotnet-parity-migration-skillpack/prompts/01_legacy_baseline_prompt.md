# PROMPT — Create Legacy Baseline Before Migration

Phân tích source code và runtime của hệ thống .NET legacy để tạo baseline đánh giá sau migration.

## Không sửa code

Không được sửa source. Không được gọi API ghi dữ liệu production. Không được làm thay đổi DB production.

## Cần tạo/cập nhật

- Endpoint catalog.
- View catalog.
- JSON compatibility profile.
- Auth/session/cookie map.
- Crypto/deep-link map.
- DB/state/external side-effect matrix.
- Static file/routing map.
- Golden Master test cases.
- Risk register.
- `legacy-baseline.json`.

## Với mỗi endpoint

Ghi rõ:

- URL, method, controller/action/source.
- Input: query/form/body/header/cookie/route.
- Output: status, content-type, headers, cookies, redirect, body.
- JSON rules: casing, null, date, enum, numeric type.
- Session read/write.
- Auth/authorization.
- Side effects.
- Verification: DISCOVERED / CODE_VERIFIED / RUNTIME_VERIFIED / TEST_VERIFIED / UNKNOWN.

## Kết luận

Không được ghi `COMPLETE` nếu còn endpoint P0/P1 chưa có Golden Master hoặc còn mâu thuẫn số lượng endpoint giữa catalog và JSON.
