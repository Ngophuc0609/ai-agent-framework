# PROMPT — Port One Endpoint/View With Parity

Port endpoint/view sau sang .NET 8+ theo chuẩn 1:1 parity:

```text
Target endpoint/view: <điền endpoint/view>
Legacy source: <điền file nếu biết>
Baseline path: <điền đường dẫn baseline>
```

## Bắt buộc

- Đọc baseline trước khi sửa.
- Không đổi request/response/view behavior.
- Không refactor nghiệp vụ.
- Không tự đổi JSON string escaped thành JSON object.
- Không tự đổi HTTP 200 error payload thành BadRequest/Unauthorized.
- Không tự đổi Request.Params chỉ thành Request.Form hoặc Request.Query.

## Sau khi sửa

Báo cáo:

```text
Files changed:
Legacy behavior preserved:
Compatibility adapters used:
Risks:
Tests run:
Diff vs baseline:
Result:
```
