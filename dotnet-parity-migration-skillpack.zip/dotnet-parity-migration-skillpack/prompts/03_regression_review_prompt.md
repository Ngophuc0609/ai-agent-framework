# PROMPT — Regression Review After Migration

So sánh output của bản .NET mới với Golden Master legacy.

## Cần kiểm tra

- Route/method.
- Request binding.
- Status code.
- Headers/cookies.
- Content-Type.
- Redirect.
- Body text.
- JSON shape/types/casing/null/date/enum.
- View HTML/static paths.
- Session/auth behavior.
- DB/external/file side effects.

## Classification

Mỗi khác biệt phải phân loại:

- MATCH
- DYNAMIC_MATCH
- APPROVED_BREAKING_CHANGE
- MIGRATION_BUG
- BLOCKED

## Output

```text
Regression Result:
Endpoint/View:
Matches:
Differences:
Migration bugs:
Blocked items:
Required fixes:
Can mark done: Yes/No
```
