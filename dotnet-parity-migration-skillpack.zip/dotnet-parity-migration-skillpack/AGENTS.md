# AGENTS.md — .NET Parity Migration Rules

Use these instructions for any task that migrates, ports, upgrades, refactors, or reviews a .NET legacy system moving to .NET 8 or newer.

## Mission

This is a **1:1 parity migration**, not a modernization/refactor project.
The internal framework may change, but all externally observable behavior must stay the same unless a breaking change is explicitly documented and approved.

## Non-negotiable rules

- Do not invent features.
- Do not add new business rules.
- Do not remove legacy behavior just because it looks wrong.
- Do not change endpoint URLs, HTTP methods, parameter names, response fields, object structure, casing, data types, null behavior, DateTime format, enum format, content-type, status codes, redirect behavior, cookie behavior, session behavior, view output, or static asset paths unless explicitly approved.
- Do not replace legacy `HTTP 200 + Success=false` with `400/401/500` unless the legacy baseline proves that behavior.
- Do not replace escaped JSON string responses with raw JSON object responses unless the Golden Master proves legacy returned raw JSON.
- Do not convert `Request.Params` mechanically to only `Request.Form` or only `Request.Query`. Build a compatibility accessor when needed.
- Do not refactor architecture or clean up business logic during parity migration.
- Never commit secrets, passwords, tokens, API keys, encryption keys, or real production credentials.

## Required workflow

Before changing code:

1. Discover legacy endpoint/view/config/auth/session/db/external dependencies.
2. Create or update a Golden Master baseline for the target endpoint/view.
3. Identify compatibility risks: JSON, model binding, auth, session, crypto, view, file, DB, external API.
4. Propose the minimal change plan.
5. Ask for approval only if the task requires a deliberate breaking change.

During code changes:

1. Port the smallest compatible slice.
2. Prefer compatibility adapters over broad rewrites.
3. Preserve legacy names and DTOs where they are part of the public contract.
4. Keep direct controller response and proxy response behavior separate.
5. Add regression tests using the Golden Master.

After code changes:

1. Run build.
2. Run tests.
3. Compare response body, status, headers, cookies, redirects, and side effects against legacy baseline.
4. Report PASS / FAIL / BLOCKED per endpoint/view.

## Compatibility checklist

For every migrated endpoint, verify:

- Route and HTTP method.
- Query/Form/Body/Header/Cookie input.
- Request content-type.
- Response status code.
- Response content-type.
- Response body shape.
- JSON casing and property names.
- Null/missing/empty behavior.
- DateTime/timezone format.
- Numeric/decimal/enum behavior.
- Response headers.
- Set-Cookie behavior.
- Redirect behavior.
- Authentication and authorization behavior.
- Session read/write keys and value types.
- Database side effects.
- External API calls.
- File upload/download behavior.
- View HTML and static asset paths.

## Output format for migration reviews

Always report:

```text
Status: PASS / FAIL / BLOCKED / PARTIAL
Endpoint/View:
Legacy evidence:
Changes made:
Compatibility risks:
Contract differences:
Tests run:
Next required action:
```
