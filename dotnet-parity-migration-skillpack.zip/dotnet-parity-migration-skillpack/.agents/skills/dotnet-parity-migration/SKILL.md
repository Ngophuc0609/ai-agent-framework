---
name: dotnet-parity-migration
description: Use this skill when migrating any .NET legacy application to .NET 8 or newer while preserving exact 1:1 behavior, API contracts, DTO structures, views, authentication, session, cookies, and external behavior.
---

# .NET Parity Migration Skill

## Goal

Upgrade the internal .NET runtime/framework while preserving all externally visible behavior exactly.

This is not a feature project and not a refactor project.

## Absolute rules

- Do not invent features.
- Do not add or remove business rules.
- Do not change public contracts.
- Do not change view output unless approved.
- Do not treat build success as acceptance.
- Do not guess legacy behavior if evidence is missing.

## Required execution flow

1. Identify app type: MVC, Web API, WebForms, WCF, Worker, Console, Desktop, mixed.
2. Build inventory: endpoints, views, routes, config, auth, session, cookies, DB, external APIs, static files.
3. Build Golden Master baseline before code changes.
4. Design compatibility adapters.
5. Port code minimally.
6. Run build and tests.
7. Compare new output to legacy baseline.
8. Report PASS / FAIL / BLOCKED.

## Compatibility adapters to prefer

- `LegacyRequestParams` for `Request.Params` behavior.
- `LegacyJsonResult` or per-endpoint response compatibility for MVC5 `JsonResult` behavior.
- `LegacySessionSerializer` for session object values.
- `LegacyPathResolver` for `Server.MapPath` behavior.
- `LegacyAuthClaimsMapper` for FormsAuth/CustomPrincipal compatibility.
- `LegacyCryptoAdapter` for old encryption/deep-link tokens.

## Prohibited shortcuts

- Do not replace `Json(string)` with `Content(string, "application/json")` unless Golden Master proves legacy returned raw JSON object.
- Do not replace validation failure `HTTP 200 + Success=false` with `BadRequest()` unless legacy did that.
- Do not infer Form vs Query only from HTTP method.
- Do not convert all Session values to strings without a session contract.
- Do not clean up old DTO property names if frontend depends on them.

## Output template

```text
Migration Step:
Target:
Legacy evidence:
Baseline status:
Risk areas:
Change plan:
Files changed:
Verification:
Result: PASS / FAIL / BLOCKED / PARTIAL
```
