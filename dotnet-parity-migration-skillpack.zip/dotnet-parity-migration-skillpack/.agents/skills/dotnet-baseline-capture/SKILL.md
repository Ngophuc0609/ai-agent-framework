---
name: dotnet-baseline-capture
description: Use this skill before migrating .NET legacy code to capture Golden Master behavior for APIs, views, JSON, cookies, sessions, redirects, database side effects, and external API behavior.
---

# .NET Legacy Baseline Capture Skill

## Goal

Create a trustworthy baseline for legacy behavior before migration.

## Required artifacts

Generate or update:

- `01_LEGACY_SYSTEM_OVERVIEW.md`
- `02_API_CONTRACT_CATALOG.md`
- `03_LEGACY_JSON_COMPATIBILITY_PROFILE.md`
- `04_AUTH_SESSION_COOKIE_MAP.md`
- `05_CRYPTO_DEEP_LINK_MAP.md`
- `06_STATE_AND_SIDE_EFFECT_MATRIX.md`
- `07_EXTERNAL_INTEGRATION_MAP.md`
- `08_VIEW_STATIC_ROUTING_MAP.md`
- `09_GOLDEN_MASTER_TEST_CASES.md`
- `10_MIGRATION_RISK_REGISTER.md`
- `legacy-baseline.json`

## Required endpoint fields

For every endpoint:

- ID
- URL
- HTTP method
- Controller/action/source file
- Auth requirement
- Authorization rule
- Request content-type
- Query/form/body/route/header/cookie parameters
- Response status
- Response content-type
- Response body shape
- JSON casing/null/date/enum behavior
- Response headers
- Set-Cookie
- Redirect behavior
- Session read/write keys
- DB/external/file side effects
- React/view consumer if any
- Verification level: DISCOVERED / CODE_VERIFIED / RUNTIME_VERIFIED / TEST_VERIFIED / UNKNOWN

## Golden Master capture

For every P0/P1 endpoint, capture:

```text
request.json
request-headers.json
request-cookies.json
expected-status.txt
response-headers.json
response-cookies.json
response-body.json or response-body.txt
dynamic-fields.json
side-effects.md
notes.md
```

## Dynamic fields

Do not hard-code tokens, timestamps, OTPs, GUIDs, random IDs, or generated links. Mark them in `dynamic-fields.json` with validation rules.

## Completion rule

Do not mark baseline COMPLETE if:

- Endpoint counts differ between catalog and JSON.
- Any P0 endpoint lacks request/response evidence.
- Crypto/deep-link has no test vector.
- Auth/session/cookie behavior is unknown.
- Proxy JSON object/string behavior is unknown.
