---
name: dotnet-contract-regression
description: Use this skill after converting .NET legacy code to compare the .NET 8+ behavior against Golden Master snapshots and decide PASS, FAIL, or BLOCKED.
---

# .NET Contract Regression Skill

## Goal

Verify that converted .NET 8+ code behaves the same as legacy code.

## Compare all observable behavior

For each endpoint/view, compare:

- URL and HTTP method.
- Request binding from query/form/body/route/header/cookie.
- HTTP status.
- Response headers.
- Content-Type.
- Set-Cookie.
- Redirect Location.
- Response body text.
- JSON property names, casing, types, null behavior, DateTime, enum.
- HTML output for views.
- Static asset links.
- DB/external/file side effects.
- Auth/session behavior.

## Difference classification

Every difference must be classified:

- `MATCH`: same as legacy.
- `DYNAMIC_MATCH`: value differs but matches approved dynamic rule.
- `APPROVED_BREAKING_CHANGE`: explicitly documented and approved.
- `MIGRATION_BUG`: unintended difference.
- `BLOCKED`: cannot verify due to missing baseline/environment.

## Completion rule

A task is Done only when all P0/P1 items are MATCH or DYNAMIC_MATCH, with no unresolved MIGRATION_BUG.

## Report format

```text
Regression Result: PASS / FAIL / BLOCKED
Endpoint/View:
Legacy baseline path:
New output path:
Matches:
Differences:
Bug classification:
Required fix:
```
