---
name: dotnet-compatibility-port
description: Use this skill when editing source code to port ASP.NET MVC/Web API/.NET Framework code to ASP.NET Core/.NET 8+ using compatibility adapters while preserving 1:1 behavior.
---

# .NET Compatibility Port Skill

## Goal

Make the smallest source changes necessary to run on .NET 8+ while preserving legacy behavior.

## Preferred patterns

### Request.Params

Do not mechanically replace with only Form or Query. Use a compatibility accessor if the legacy action reads mixed sources.

### JsonResult

Determine endpoint behavior from Golden Master:

- If legacy returned raw JSON object, return equivalent raw JSON object.
- If legacy returned escaped JSON string, return equivalent escaped JSON string.

### FormsAuthentication

Map old principal fields to ClaimsPrincipal without changing consumer behavior.

### Session

Map each session key with its old type and TTL. Use explicit serialization for objects.

### HttpContext.Current

Pass required context explicitly or use `IHttpContextAccessor` only at boundaries.

### Server.MapPath

Use environment/path resolver wrapper to preserve relative path behavior.

### Web.config

Move settings to appsettings/environment, but preserve key names through a compatibility settings wrapper if legacy code expects them.

## Review before commit

- No business logic refactor.
- No DTO rename.
- No serializer default drift.
- No new validation.
- No auth behavior drift.
- No view path/static path drift.
- No secret leakage.
