# Cline Rule — .NET 1:1 Parity Migration

Use this rule for all migration tasks from .NET Framework / ASP.NET MVC / legacy .NET to .NET 8+.

## Work mode

Plan first. Act only after identifying baseline/evidence for the target files.

## Hard constraints

- No invented features.
- No unapproved contract changes.
- No unapproved business logic changes.
- No broad refactor in parity phase.
- No secrets in output or commits.

## Required checks before edits

1. Identify the endpoint/view/class being migrated.
2. Locate legacy source evidence.
3. Locate or create Golden Master expected behavior.
4. List compatibility risks.
5. Modify only the smallest necessary scope.

## Required checks after edits

1. Build.
2. Run tests.
3. Compare migrated behavior with baseline.
4. Report differences.

If baseline is missing, stop and create baseline instead of guessing behavior.
